# 공개 전 콘텐츠 검수

## 확인된 자료

- 기존 이메일: jyin2205@naver.com
- GitHub: jiyu-in (현재 저장소 소유자)
- 개인자산관리: 기존 ProjectFinance의 서비스 소개·UX 방향·디자인 접근·퍼블리싱 기록을 재사용
- 모든 기존 Notion 상세 링크 유지

## 실제 이력 확인 필요

`src/data/profileData.js`에 있는 아래 값은 요청 시안의 내용을 반영했습니다. 실제 이력인지 최종 확인해야 합니다.

- [ ] 경력 시작 2016년 / 10년 이상
- [ ] 프로젝트 50개 이상
- [ ] MEDIA / FINANCE / CRYPTO / EDUCATION / PUBLIC / CORPORATE 산업 경험
- [ ] 현재 이메일과 GitHub의 공개 사용 확인

## 대표 작업별 입력

| 프로젝트 | 현재 자료 | 필요한 자료 |
| --- | --- | --- |
| PERSONAL FINANCE | 기존 소개·설계·퍼블리싱 기록 | 실제 UI 캡처, 작업 연도, 사용 기술, 공개 가능 범위, 실제 결과 |
| CRYPTO EXCHANGE | 제목·분야·기존 Notion 링크 | 실제 UI 캡처, 연도, 역할, 문제·접근·디자인·구현·결과 |
| LEARNING PLATFORM | 제목·분야·기존 Notion 링크 | 실제 UI 캡처, 연도, 역할, 문제·접근·디자인·구현·결과 |
| SNU DEPARTMENT | 제목·분야·기존 Notion 링크 | 실제 UI 캡처, 연도, 역할, 문제·접근·디자인·구현·결과 |

각 프로젝트는 다음 형식으로 자료를 정리하면 바로 반영할 수 있습니다.

```text
프로젝트 ID:
작업 연도:
담당 역할:
사용 기술:
Overview:
Problem:
Approach:
Design:
Implementation:
Result: (실제 확인된 결과만; 수치가 없어도 실제 출시·적용 범위를 설명 가능)
실제 화면 이미지:
공개 가능한 정보/가려야 하는 정보:
```

사진은 `public/assets/`에 보관하고 `thumbnail`, `heroImage`, `imageWidth`, `imageHeight`를 실제 파일에 맞춰 수정합니다.
이미지 경로는 `import.meta.env.BASE_URL + 'assets/파일명'`을 사용합니다.
실제 캡처로 교체하면 `imageKind`를 `reference`에서 `screenshot`으로 변경합니다.
현재 이미지를 실서비스 UI 화면으로 소개하지 않습니다.

## Notion 접근 상태

이 클라우드에서는 기존 Notion 도메인에 대한 요청이 프록시 403으로 차단됐습니다.
`sumptuous-amaryllis-ad1.notion.site` 도메인 추가를 환경 설정 초안에 저장했습니다.
초안 저장만으로 현재 네트워크가 변경되지는 않습니다. 환경 설정에 반영된 뒤 접근을 다시 확인해야 합니다.
페이지가 공개되어 있는지도 별도 확인이 필요하며, 접근 가능한 전체 본문과 실제 UI 캡처는 아직 검증하지 못했습니다.
로그인 토큰이나 비밀번호를 코드·채팅에 넣지 않습니다.
