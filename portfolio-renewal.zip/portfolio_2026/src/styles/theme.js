export const theme = {
  colors: {
    background: '#F7F1E8',
    surface: '#EEE7DB',
    text: '#1F1F1F',
    secondary: '#666666',
    line: '#D6CCBC',
    accent: '#344B39',
    // Small text needs stronger contrast than the original decorative palette.
    secondaryText: '#666666',
    accentText: '#344B39',
  },
  layout: { maxWidth: '1600px' },
  breakpoints: { tablet: '1199px', mobile: '767px' },
};
