export const theme = {
  colors: {
    background: '#F7F8FB',
    surface: '#FFFFFF',
    surfaceSoft: '#EEF1F6',
    text: '#1D1F27',
    secondary: '#737782',
    line: '#E1E5EC',
    accent: '#2E3A59',
    accentSoft: '#E8ECF5',
    // Slightly deeper than secondary: small text also meets AA on surface.
    secondaryText: '#626A78',
    accentText: '#2E3A59',
  },
  typography: {
    hero: 'clamp(56px, 6.5vw, 104px)',
    section: 'clamp(40px, 5.5vw, 80px)',
    project: 'clamp(30px, 3vw, 46px)',
    body: '16px',
    caption: '12px',
  },
  layout: { maxWidth: '1600px' },
  breakpoints: { tablet: '1199px', mobile: '767px' },
};
