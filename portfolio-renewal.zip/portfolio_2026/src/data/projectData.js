import { projectData as originalProjects } from '../projects/data/projectData';

// Current images are existing reference photos, not verified service screenshots.
// Replace thumbnail and heroImage with actual UI captures before publication.
// Original assets and live Notion links are retained. Confirm years and
// project-specific roles before publishing; no dates or achievements are invented.
const selection = [
  { source: 'Dabang', id: 'personal-finance', title: 'PERSONAL FINANCE', subtitle: '개인자산관리', description: '부동산과 금융 정보를 연결하는 개인 자산관리 서비스.' },
  { source: 'ProjectCryptoExchange', id: 'crypto-exchange', title: 'CRYPTO EXCHANGE', subtitle: '가상화폐거래소 UI/UX', description: '복잡한 거래 정보를 정리하는 디지털 금융 인터페이스.' },
  { source: 'OnlineEduSystem', id: 'learning-platform', title: 'LEARNING PLATFORM', subtitle: '비대면 학습관리시스템', description: '온라인 학습을 위한 교육 서비스 인터페이스.' },
  { source: 'SnuDeptRenewal', id: 'snu-renewal', title: 'SNU DEPARTMENT', subtitle: '서울대학교 학과 페이지 리뉴얼', description: '학과의 정보를 전달하는 대학 웹사이트 리뉴얼.' },
];
// Reused and condensed from the existing ProjectFinance page.
// Expected benefits are not presented as measured results.
const caseStudies = {
  'personal-finance': {
    roles: ['UI/UX Design', 'Publishing'],
    overview: '기존 부동산 중개 서비스에서 금융·자산관리로 확장한 개인 자산관리 대시보드입니다. 부동산을 포함한 자산과 금융 정보를 직관적으로 제공하여, 사용자가 자신의 재무 상태를 파악하고 의사결정을 할 수 있도록 설계했습니다.',
    problem: '부동산 거래 과정에서 대출·보험·투자 등 여러 금융 서비스가 필요합니다. 사용자가 자산, 대출, 투자 정보를 한눈에 확인하고 부동산 서비스와 금융 서비스 사이의 흐름을 이어갈 수 있도록 정보를 정리하는 것이 주요 목표였습니다.',
    approach: '다방을 이용하는 일반 고객을 대상으로 자산, 대출, 투자 정보를 우선 배치했습니다. 최근 거래 내역과 대출 현황을 목적별로 그룹화하고, 자산 분석·지출 분석 등 숫자 정보를 그래프와 시각 요소로 이해할 수 있도록 구성했습니다.',
    design: '기존 다방의 블루 계열 브랜드 컬러를 유지했습니다. 사이드바로 내비게이션을 구분하고, 서비스 내 각 정보 영역을 카드로 정리했습니다. 중요한 데이터는 컬러와 글자 크기로 구분하여 금융 정보의 우선순위를 전달했습니다.',
    implementation: '대시보드의 서비스 화면을 퍼블리싱했습니다. 기존 자료에는 완성된 퍼블리싱 화면과 부동산 자산 연결·검색 화면의 추가 작업 내용이 기록되어 있습니다.',
    result: null,
    todo: ['실제 UI 화면 이미지 교체', '실제 서비스 적용 범위·구현 기술 확인', '측정된 성과 확인', '작업 연도 확인'],
  },
};

export const projectData = selection.map((project, index) => {
  const original = originalProjects.find(item => item.componentName === project.source) || {};
  const thumbnail = project.thumbnail || original.img || null;
  return {
    index: String(index + 1).padStart(2, '0'), year: null,
    categories: original.category || [], roles: [], skills: [], thumbnail,
    heroImage: project.heroImage || thumbnail, url: original.url || null,
    imageKind: 'reference', imageAlt: null, imageCaption: null,
    imageWidth: 1920, imageHeight: 1329,
    overview: project.description || null, problem: null, approach: null,
    design: null, implementation: null, result: null,
    todo: ['실제 UI 화면 이미지 교체', '상세 case study 본문·성과 확인', '작업 연도 확인', '프로젝트별 Role / Skills 확인'],
    ...caseStudies[project.id],
    ...project,
  };
});
