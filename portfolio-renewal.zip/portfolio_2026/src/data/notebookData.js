export const notebookData = {
  slogan: ['Designing Interfaces,', 'Building Experiences.'],
  introduction: '화면을 설계하고, 경험으로 구현하는 UI/UX 디자이너 & 퍼블리셔',
  heroVisualLabel: '프로젝트 테마를 소개하는 레이아웃 프리뷰',
  previewLabel: 'LAYOUT PREVIEW · 실제 작업 화면 아님',
  screenLabel: 'PROJECT SCREEN',
  notebookLabel: 'PROJECT NOTES / 01—04',
  notebookDescription: '화면을 만들기까지의 생각과 작업을 기록합니다.',
  scopeLabel: 'KEY WORK',
};
