export const profileData = {
  name: 'JIYU',
  introduction: '디자인과 구현 사이의 간극을 줄이며, 사용자에게 더 나은 경험을 만드는 일을 합니다.',
  description: '다양한 산업의 웹 서비스를 디자인하고 구현해왔습니다. 사용자의 흐름을 설계하고, 실제 개발 환경에서 구현 가능한 UI를 만드는 것을 중요하게 생각합니다.',
  stats: [
    { value: '10+', label: 'YEARS EXPERIENCE' },
    { value: '50+', label: 'PROJECTS' },
    { value: '6', label: 'INDUSTRIES' },
  ],
  skills: [
    { title: 'DESIGN', items: ['Figma', 'Photoshop', 'Illustrator', 'UI/UX Design', 'Design System'] },
    { title: 'DEVELOPMENT', items: ['HTML', 'CSS / SCSS', 'JavaScript', 'React', 'Styled Components', 'Responsive Web', 'Git', 'Vue', 'jQuery', 'Webpack', 'MUI'] },
  ],
  experience: {
    start: '2016', end: '2026',
    industries: ['MEDIA', 'FINANCE', 'CRYPTO', 'EDUCATION', 'PUBLIC', 'CORPORATE'],
  },
  // Email is reused from the original About component; GitHub from repository identity.
  email: 'jyin2205@naver.com',
  github: 'https://github.com/jiyu-in',
  githubLabel: 'jiyu-in',
  linkedin: null,
  todo: ['공개 전 경력 시작 연도·프로젝트 수·산업 경험 최종 확인'],
};
