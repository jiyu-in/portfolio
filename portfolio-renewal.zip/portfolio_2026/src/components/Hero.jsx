import { heroData } from '../data/heroData';
import {
  Accent,
  AnimatedLine,
  Disciplines,
  Edition,
  Eyebrow,
  HeroFooter,
  HeroSection,
  Introduction,
  IntroductionText,
  ScrollLabel,
  ScrollLink,
  Title,
  TitleLine,
} from './Hero.styles';

export default function Hero() {
  return (
    <HeroSection id="hero" className="container" aria-labelledby="hero-title">
      <div>
        <Eyebrow>{heroData.eyebrow}</Eyebrow>
        <Title id="hero-title">
          {heroData.titleLines.map((line) => (
            <TitleLine key={line.id} $indented={line.indented}>
              <AnimatedLine $delay={line.delay}>
                {line.text}
                {line.accent && (
                  <Accent aria-hidden="true">{line.accent}</Accent>
                )}
              </AnimatedLine>
            </TitleLine>
          ))}
        </Title>
        <Introduction>
          <IntroductionText>{heroData.introduction}</IntroductionText>
        </Introduction>
        <Edition>{heroData.edition}</Edition>
      </div>
      <HeroFooter>
        <Disciplines>{heroData.disciplines.join(' / ')}</Disciplines>
        <ScrollLink href="#work" aria-label="Selected Works로 이동">
          <ScrollLabel>SCROLL TO EXPLORE</ScrollLabel>
          <ScrollLabel $compact>SCROLL</ScrollLabel>
          <span aria-hidden="true">↓</span>
        </ScrollLink>
      </HeroFooter>
    </HeroSection>
  );
}
