import styled from 'styled-components';

export const Root = styled.article`
  display: grid;
  grid-template-columns: ${({ $hasImage }) =>
    $hasImage ? 'minmax(0, 1fr) minmax(0, 1.2fr)' : 'minmax(0, 1fr)'};
  grid-template-areas: ${({ $hasImage }) =>
    $hasImage ? '"copy image"' : '"copy"'};
  gap: clamp(40px, 6vw, 100px);
  padding-block: 64px;
  border-bottom: 1px solid var(--line);
  align-items: center;
  .project-copy {
    grid-area: copy;
    min-width: 0;
  }
  &:nth-of-type(even) {
    grid-template-columns: ${({ $hasImage }) =>
      $hasImage ? 'minmax(0, 1.2fr) minmax(0, 1fr)' : 'minmax(0, 1fr)'};
    grid-template-areas: ${({ $hasImage }) =>
      $hasImage ? '"image copy"' : '"copy"'};
  }
  .metadata {
    display: flex;
    justify-content: space-between;
    margin-bottom: 40px;
    font-size: 13px;
  }
  .number {
    color: var(--accent-text);
    font-weight: 700;
  }
  .year {
    color: var(--text-muted);
  }
  h3 {
    font-size: clamp(36px, 4.5vw, 68px);
    line-height: 1.02;
    letter-spacing: -0.055em;
    overflow-wrap: anywhere;
    text-wrap: balance;
  }
  .subtitle {
    margin-top: 16px;
    font-size: 18px;
  }
  .description {
    margin-top: 24px;
    max-width: 350px;
    font-size: 16px;
    color: var(--text-muted);
    word-break: keep-all;
  }
  ul {
    list-style: none;
    margin: 24px 0 40px;
    padding: 0;
    display: flex;
    flex-wrap: wrap;
    gap: 6px 18px;
    font-size: 12px;
    color: var(--text-muted);
  }
  .view {
    display: inline-flex;
    align-items: center;
    gap: 32px;
    font-size: 12px;
    font-weight: 700;
    letter-spacing: 0.6px;
    border-bottom: 1px solid var(--text-primary);
    min-height: 44px;
    padding-block: 10px;
    transition: color 0.6s;
  }
  .view span {
    transition: transform 0.6s;
  }
  .view:hover {
    color: var(--accent-text);
  }
  .view:hover span {
    transform: translateX(5px);
  }
  .image {
    grid-area: image;
    min-width: 0;
  }
  img {
    width: 100%;
    height: auto;
    aspect-ratio: 4 / 3;
    object-fit: contain;
    transition: transform 0.6s ease;
  }
  .image:hover img {
    transform: scale(1.025);
  }
  @media (max-width: ${({ theme }) => theme.breakpoints.tablet}) {
    gap: 32px;
  }
  @media (max-width: ${({ theme }) => theme.breakpoints.mobile}) {
    &,
    &:nth-of-type(even) {
      grid-template-columns: minmax(0, 1fr);
      grid-template-areas: ${({ $hasImage }) =>
        $hasImage ? '"image" "copy"' : '"copy"'};
    }
    gap: 28px;
    padding-block: 40px;
    .metadata {
      margin-bottom: 24px;
    }
    .subtitle {
      margin-top: 12px;
    }
    .description {
      margin-top: 16px;
    }
    ul {
      margin: 20px 0 24px;
    }
  }
`;
