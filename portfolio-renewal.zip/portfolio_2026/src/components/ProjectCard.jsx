import { siteData } from '../data/siteData';
import { Root } from './ProjectCard.styles';
import { Link } from 'react-router-dom';
import ProjectImage from './ProjectImage';
import { contentText, contentList } from '../data/contentUtils';

export default function ProjectCard({ project }) {
  const roles = contentList(project.roles);
  const tags = roles.length ? roles : contentList(project.categories);
  return (
    <Root
      $hasImage={Boolean(contentText(project.thumbnail))}
      aria-labelledby={`project-${project.id}`}
    >
      <div className="project-copy">
        <div className="metadata">
          <span className="number">/{project.index}</span>
          {contentText(project.year) && (
            <span className="year">{project.year}</span>
          )}
        </div>
        <h3 id={`project-${project.id}`}>{project.title}</h3>
        <p className="subtitle">
          {project.subtitle}
          {contentText(project.projectType) && ` · ${project.projectType}`}
        </p>
        {contentText(project.description) && (
          <p className="description">{project.description}</p>
        )}
        {tags.length > 0 && (
          <ul
            aria-label={
              roles.length
                ? siteData.works.rolesLabel
                : siteData.works.industryLabel
            }
          >
            {tags.map((category) => (
              <li key={category}>{category}</li>
            ))}
          </ul>
        )}
        <Link
          className="view"
          to={`/project/${project.id}`}
          aria-label={`${project.subtitle} ${siteData.works.linkSuffix}`}
        >
          {siteData.works.link} <span aria-hidden="true">↗</span>
        </Link>
      </div>
      <ProjectImage className="image" project={project} />
    </Root>
  );
}
