import styled, { keyframes } from 'styled-components';
import SectionLink from './SectionLink';

const titleReveal = keyframes`
  from {
    opacity: 0;
    transform: translateY(105%);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
`;

export const HeroSection = styled.section`
  min-height: calc(95vh - 72px);
  min-height: calc(95svh - 72px);
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  padding-top: clamp(48px, 7vh, 100px);
  padding-bottom: 32px;

  @media (max-width: ${({ theme }) => theme.breakpoints.mobile}) {
    min-height: calc(90vh - 72px);
    min-height: calc(90svh - 72px);
    padding-top: 56px;
    padding-bottom: 24px;
  }
`;

export const Eyebrow = styled.p`
  font-size: 13px;
  font-weight: 600;
  letter-spacing: 1.5px;
`;

export const Title = styled.h1`
  margin-top: 30px;
  font-size: clamp(72px, 12vw, 170px);
  font-weight: 900;
  line-height: 0.88;
  letter-spacing: -0.075em;

  @media (max-width: ${({ theme }) => theme.breakpoints.mobile}) {
    margin-top: 48px;
    font-size: clamp(56px, 16vw, 128px);
  }
`;

// Extra space protects glyph edges while the frame masks the entrance motion.
export const TitleLine = styled.span`
  display: block;
  overflow: hidden;
  padding-block: 0.14em;
  margin-block: -0.14em;
  padding-left: ${({ $indented }) => $indented ? '17%' : '0'};

  @media (max-width: ${({ theme }) => theme.breakpoints.mobile}) {
    padding-left: ${({ $indented }) => $indented ? '8%' : '0'};
  }
`;

export const AnimatedLine = styled.span`
  display: block;
  white-space: nowrap;
  animation: ${titleReveal} 900ms cubic-bezier(0.22, 1, 0.36, 1) both;
  animation-delay: ${({ $delay }) => $delay}ms;

  @media (prefers-reduced-motion: reduce) {
    animation: none;
    opacity: 1;
    transform: none;
  }
`;

export const Accent = styled.span`
  font-weight: 400;
  color: var(--accent);
`;

export const Introduction = styled.div`
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  margin-top: 48px;

  @media (max-width: ${({ theme }) => theme.breakpoints.mobile}) {
    display: block;
    margin-top: 40px;
  }
`;

export const IntroductionText = styled.p`
  grid-column: 2;
  max-width: 400px;
  font-size: 18px;
  word-break: keep-all;

  @media (max-width: ${({ theme }) => theme.breakpoints.mobile}) {
    max-width: 280px;
    font-size: 16px;
  }
`;

export const Edition = styled.p`
  margin-top: 28px;
  font-size: 12px;
  letter-spacing: 1.2px;
  color: var(--text-muted);
`;

export const HeroFooter = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: flex-end;
  gap: 24px;
  border-top: 1px solid var(--line);
  padding-top: 20px;
  margin-top: 60px;
  font-size: 12px;
  letter-spacing: 0.5px;

  @media (max-width: ${({ theme }) => theme.breakpoints.mobile}) {
    align-items: flex-start;
    margin-top: 56px;
  }
`;

export const Disciplines = styled.p`
  color: var(--text-muted);

  @media (max-width: ${({ theme }) => theme.breakpoints.mobile}) {
    max-width: 190px;
    line-height: 1.9;
  }
`;

export const ScrollLink = styled(SectionLink)`
  display: flex;
  align-items: center;
  gap: 20px;
  min-height: 44px;
  transition: color 500ms;

  &:hover {
    color: var(--accent-text);
  }

  @media (max-width: ${({ theme }) => theme.breakpoints.mobile}) {
    align-self: center;
    gap: 10px;
    white-space: nowrap;
  }
`;

export const ScrollLabel = styled.span`
  display: ${({ $compact }) => $compact ? 'none' : 'inline'};

  @media (max-width: ${({ theme }) => theme.breakpoints.mobile}) {
    display: ${({ $compact }) => $compact ? 'inline' : 'none'};
  }
`;
